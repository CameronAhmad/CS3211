package edu.westga.cs3211.pirateinventory.model;

public enum Role {
	CREWMATE,
	QUARTERMASTER

}

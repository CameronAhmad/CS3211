package edu.westga.cs3211.pirateinventory.model;

public class CrewMate extends User {

	    public CrewMate(String username, String password) {
	        super(username, password, Role.CREWMATE);
	    }
	}
package edu.westga.cs3211.pirateinventory.model;

public enum Condition {
	PERFECT,
    USABLE,
    UNUSABLE
}

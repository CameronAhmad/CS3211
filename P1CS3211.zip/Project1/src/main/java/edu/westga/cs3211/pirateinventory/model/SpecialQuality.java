package edu.westga.cs3211.pirateinventory.model;

public enum SpecialQuality {
	FLAMMABLE,
    LIQUID,
    PERISHABLE

}
